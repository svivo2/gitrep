This program tackles the consumer producer problem without using input
